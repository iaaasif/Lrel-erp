'use client';

interface Activity {
  id: string;
  type: string;
  message: string;
  time: string;
  user: string;
  status: 'success' | 'warning' | 'info' | 'error';
}

const activities: Activity[] = [
  {
    id: '1',
    type: 'Project',
    message: 'Ocean View Towers project milestone completed',
    time: '2 hours ago',
    user: 'John Smith',
    status: 'success'
  },
  {
    id: '2',
    type: 'Purchase',
    message: 'Steel reinforcement purchase order #PO-2024-001 approved',
    time: '4 hours ago',
    user: 'Sarah Johnson',
    status: 'info'
  },
  {
    id: '3',
    type: 'Inventory',
    message: 'Cement stock running low - 50 bags remaining',
    time: '6 hours ago',
    user: 'System Alert',
    status: 'warning'
  },
  {
    id: '4',
    type: 'CRM',
    message: 'New client inquiry for residential project',
    time: '8 hours ago',
    user: 'Mike Davis',
    status: 'info'
  },
  {
    id: '5',
    type: 'HRM',
    message: 'Construction crew schedule updated for next week',
    time: '1 day ago',
    user: 'Lisa Chen',
    status: 'success'
  }
];

const statusColors = {
  success: 'bg-green-100 text-green-800',
  warning: 'bg-yellow-100 text-yellow-800',
  info: 'bg-blue-100 text-blue-800',
  error: 'bg-red-100 text-red-800'
};

const statusIcons = {
  success: 'ri-check-line',
  warning: 'ri-alert-line',
  info: 'ri-information-line',
  error: 'ri-error-warning-line'
};

export default function RecentActivity() {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
        <button className="text-blue-600 hover:text-blue-700 text-sm font-medium whitespace-nowrap">
          View All
        </button>
      </div>
      
      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
            <div className={`w-8 h-8 ${statusColors[activity.status]} rounded-full flex items-center justify-center flex-shrink-0`}>
              <i className={`${statusIcons[activity.status]} w-4 h-4 flex items-center justify-center`}></i>
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-1">
                <span className="text-xs font-medium text-gray-500 bg-gray-100 px-2 py-1 rounded">
                  {activity.type}
                </span>
              </div>
              <p className="text-sm text-gray-900 mb-1">{activity.message}</p>
              <div className="flex items-center text-xs text-gray-500 space-x-2">
                <span>{activity.user}</span>
                <span>•</span>
                <span>{activity.time}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}