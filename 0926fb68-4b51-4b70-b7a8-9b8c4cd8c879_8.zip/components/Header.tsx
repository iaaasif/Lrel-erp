'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Header() {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const toggleDropdown = (dropdown: string) => {
    setActiveDropdown(activeDropdown === dropdown ? null : dropdown);
  };

  return (
    <header className="bg-white border-b border-gray-200 shadow-sm">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link href="/" className="font-pacifico text-2xl text-blue-600">
              logo
            </Link>
            
            <nav className="flex items-center space-x-6">
              <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium whitespace-nowrap">
                Dashboard
              </Link>
              
              <div className="relative">
                <button
                  onClick={() => toggleDropdown('projects')}
                  className="flex items-center text-gray-700 hover:text-blue-600 font-medium whitespace-nowrap"
                >
                  Projects
                  <i className="ri-arrow-down-s-line ml-1 w-4 h-4 flex items-center justify-center"></i>
                </button>
                {activeDropdown === 'projects' && (
                  <div className="absolute top-full left-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
                    <Link href="/projects" className="block px-4 py-2 text-gray-700 hover:bg-gray-50 whitespace-nowrap">
                      All Projects
                    </Link>
                    <Link href="/projects/locations" className="block px-4 py-2 text-gray-700 hover:bg-gray-50 whitespace-nowrap">
                      Project Locations
                    </Link>
                  </div>
                )}
              </div>

              <div className="relative">
                <button
                  onClick={() => toggleDropdown('procurement')}
                  className="flex items-center text-gray-700 hover:text-blue-600 font-medium whitespace-nowrap"
                >
                  Procurement
                  <i className="ri-arrow-down-s-line ml-1 w-4 h-4 flex items-center justify-center"></i>
                </button>
                {activeDropdown === 'procurement' && (
                  <div className="absolute top-full left-0 mt-2 w-56 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
                    <Link href="/inventory" className="block px-4 py-2 text-gray-700 hover:bg-gray-50 whitespace-nowrap">
                      Inventory
                    </Link>
                    <Link href="/purchase-requisition" className="block px-4 py-2 text-gray-700 hover:bg-gray-50 whitespace-nowrap">
                      Purchase Requisition
                    </Link>
                    <Link href="/purchase-confirm" className="block px-4 py-2 text-gray-700 hover:bg-gray-50 whitespace-nowrap">
                      Purchase Confirm
                    </Link>
                    <Link href="/purchase-order" className="block px-4 py-2 text-gray-700 hover:bg-gray-50 whitespace-nowrap">
                      Purchase Orders
                    </Link>
                  </div>
                )}
              </div>

              <Link href="/accounts" className="text-gray-700 hover:text-blue-600 font-medium whitespace-nowrap">
                Accounts
              </Link>
              
              <Link href="/hrm" className="text-gray-700 hover:text-blue-600 font-medium whitespace-nowrap">
                HRM
              </Link>
              
              <Link href="/crm" className="text-gray-700 hover:text-blue-600 font-medium whitespace-nowrap">
                CRM
              </Link>
              
              <Link href="/reports" className="text-gray-700 hover:text-blue-600 font-medium whitespace-nowrap">
                Reports
              </Link>
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600">
              <i className="ri-notification-line w-5 h-5 flex items-center justify-center"></i>
            </button>
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-medium">
              A
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}