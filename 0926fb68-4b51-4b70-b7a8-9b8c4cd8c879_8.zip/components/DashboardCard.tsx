'use client';

interface DashboardCardProps {
  title: string;
  value: string;
  subtitle: string;
  icon: string;
  color: string;
  trend?: {
    value: string;
    isUp: boolean;
  };
}

export default function DashboardCard({ title, value, subtitle, icon, color, trend }: DashboardCardProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-all duration-200">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-gray-600 text-sm font-medium">{title}</p>
          <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
          <p className="text-gray-500 text-sm mt-1">{subtitle}</p>
          
          {trend && (
            <div className="flex items-center mt-3">
              <i className={`${trend.isUp ? 'ri-arrow-up-line text-green-600' : 'ri-arrow-down-line text-red-600'} w-4 h-4 flex items-center justify-center mr-1`}></i>
              <span className={`text-sm font-medium ${trend.isUp ? 'text-green-600' : 'text-red-600'}`}>
                {trend.value}
              </span>
              <span className="text-gray-500 text-sm ml-1">vs last month</span>
            </div>
          )}
        </div>
        
        <div className={`w-12 h-12 ${color} rounded-lg flex items-center justify-center`}>
          <i className={`${icon} text-white w-6 h-6 flex items-center justify-center`}></i>
        </div>
      </div>
    </div>
  );
}