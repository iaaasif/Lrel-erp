'use client';

export default function AccountsSummary() {
  const summaryData = [
    {
      title: 'Total Assets',
      amount: '$8,450,000',
      change: '+12.5%',
      isPositive: true,
      icon: 'ri-bank-line',
      color: 'bg-blue-600'
    },
    {
      title: 'Total Liabilities',
      amount: '$2,850,000',
      change: '+5.2%',
      isPositive: false,
      icon: 'ri-bank-card-line',
      color: 'bg-red-600'
    },
    {
      title: 'Total Equity',
      amount: '$5,600,000',
      change: '+18.3%',
      isPositive: true,
      icon: 'ri-line-chart-line',
      color: 'bg-green-600'
    },
    {
      title: 'Net Income',
      amount: '$1,240,000',
      change: '+22.7%',
      isPositive: true,
      icon: 'ri-money-dollar-circle-line',
      color: 'bg-purple-600'
    }
  ];

  const cashFlow = [
    { month: 'Jan', inflow: 850000, outflow: 620000 },
    { month: 'Feb', inflow: 920000, outflow: 680000 },
    { month: 'Mar', inflow: 780000, outflow: 590000 },
    { month: 'Apr', inflow: 1100000, outflow: 750000 },
    { month: 'May', inflow: 950000, outflow: 710000 },
    { month: 'Jun', inflow: 1200000, outflow: 820000 }
  ];

  const recentTransactions = [
    {
      id: '1',
      date: '2024-01-15',
      description: 'Steel Purchase - Ocean View Project',
      account: 'Materials Expense',
      amount: -85000,
      type: 'expense'
    },
    {
      id: '2',
      date: '2024-01-14',
      description: 'Client Payment - Sunset Residences',
      account: 'Accounts Receivable',
      amount: 450000,
      type: 'income'
    },
    {
      id: '3',
      date: '2024-01-12',
      description: 'Equipment Rental Payment',
      account: 'Equipment Expense',
      amount: -25000,
      type: 'expense'
    },
    {
      id: '4',
      date: '2024-01-10',
      description: 'Subcontractor Payment',
      account: 'Subcontractor Costs',
      amount: -120000,
      type: 'expense'
    },
    {
      id: '5',
      date: '2024-01-08',
      description: 'Progress Payment - City Mall',
      account: 'Project Revenue',
      amount: 380000,
      type: 'income'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {summaryData.map((item, index) => (
          <div key={index} className="bg-gray-50 rounded-lg p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-gray-600 text-sm font-medium">{item.title}</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">{item.amount}</p>
                <div className="flex items-center mt-2">
                  <i className={`${item.isPositive ? 'ri-arrow-up-line text-green-600' : 'ri-arrow-down-line text-red-600'} w-4 h-4 flex items-center justify-center mr-1`}></i>
                  <span className={`text-sm font-medium ${item.isPositive ? 'text-green-600' : 'text-red-600'}`}>
                    {item.change}
                  </span>
                  <span className="text-gray-500 text-sm ml-1">vs last quarter</span>
                </div>
              </div>
              <div className={`w-12 h-12 ${item.color} rounded-lg flex items-center justify-center`}>
                <i className={`${item.icon} text-white w-6 h-6 flex items-center justify-center`}></i>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Cash Flow Overview</h3>
          <div className="space-y-4">
            {cashFlow.map((month) => (
              <div key={month.month} className="flex items-center justify-between">
                <div className="w-12 text-sm font-medium text-gray-700">{month.month}</div>
                <div className="flex-1 mx-4">
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 bg-gray-200 rounded-full h-3 relative">
                      <div 
                        className="bg-green-500 h-3 rounded-full" 
                        style={{ width: `${(month.inflow / 1200000) * 100}%` }}
                      ></div>
                      <div 
                        className="bg-red-500 h-3 rounded-full absolute top-0" 
                        style={{ width: `${(month.outflow / 1200000) * 100}%`, opacity: 0.7 }}
                      ></div>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-green-600">
                    +${(month.inflow / 1000).toFixed(0)}K
                  </div>
                  <div className="text-sm font-medium text-red-600">
                    -${(month.outflow / 1000).toFixed(0)}K
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-gray-700">Cash Inflow</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span className="text-gray-700">Cash Outflow</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Recent Transactions</h3>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium whitespace-nowrap">
              View All
            </button>
          </div>
          <div className="space-y-3">
            {recentTransactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-3 bg-white rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    <i className={`${
                      transaction.type === 'income' ? 'ri-arrow-down-line text-green-600' : 'ri-arrow-up-line text-red-600'
                    } w-4 h-4 flex items-center justify-center`}></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{transaction.description}</p>
                    <p className="text-xs text-gray-600">{transaction.account} • {transaction.date}</p>
                  </div>
                </div>
                <div className={`text-sm font-medium ${
                  transaction.amount > 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {transaction.amount > 0 ? '+' : ''}${Math.abs(transaction.amount).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}