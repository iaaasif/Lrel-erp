
'use client';

import { useState } from 'react';

export default function FinancialReports() {
  const [selectedReport, setSelectedReport] = useState('balance-sheet');
  const [reportPeriod, setReportPeriod] = useState('current');
  const [showPrintDialog, setShowPrintDialog] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);

  const reports = [
    {
      id: 'balance-sheet',
      name: 'Balance Sheet',
      description: 'Financial position at a specific point in time',
      icon: 'ri-scales-line'
    },
    {
      id: 'income-statement',
      name: 'Income Statement',
      description: 'Revenue and expenses over a period',
      icon: 'ri-line-chart-line'
    },
    {
      id: 'cash-flow',
      name: 'Cash Flow Statement',
      description: 'Cash inflows and outflows',
      icon: 'ri-exchange-funds-line'
    },
    {
      id: 'project-profitability',
      name: 'Project Profitability',
      description: 'Profit analysis by project',
      icon: 'ri-building-line'
    },
    {
      id: 'aging-report',
      name: 'Accounts Aging',
      description: 'Outstanding receivables and payables',
      icon: 'ri-time-line'
    },
    {
      id: 'budget-variance',
      name: 'Budget vs Actual',
      description: 'Compare budgeted vs actual amounts',
      icon: 'ri-contrast-line'
    }
  ];

  const balanceSheetData = {
    assets: [
      { 
        name: 'Current Assets', 
        items: [
          { name: 'Cash - Operating', amount: 450000 }, 
          { name: 'Cash - Payroll', amount: 125000 }, 
          { name: 'Accounts Receivable', amount: 850000 }, 
          { name: 'Inventory - Materials', amount: 320000 }
        ]
      },
      { 
        name: 'Fixed Assets', 
        items: [
          { name: 'Equipment', amount: 2500000 }, 
          { name: 'Vehicles', amount: 680000 }, 
          { name: 'Less: Accumulated Depreciation', amount: -450000 }
        ]
      }
    ],
    liabilities: [
      { 
        name: 'Current Liabilities', 
        items: [
          { name: 'Accounts Payable', amount: 280000 }, 
          { name: 'Accrued Payroll', amount: 95000 }, 
          { name: 'Current Portion - Equipment Loans', amount: 150000 }
        ]
      },
      { 
        name: 'Long-term Liabilities', 
        items: [
          { name: 'Equipment Loans', amount: 1050000 }, 
          { name: 'Line of Credit', amount: 350000 }
        ]
      }
    ],
    equity: [
      { name: 'Owner\'s Equity', amount: 3800000 }, 
      { name: 'Retained Earnings', amount: 1850000 }, 
      { name: 'Current Year Earnings', amount: 450000 }
    ]
  };

  const incomeStatementData = [
    { 
      category: 'Revenue', 
      items: [
        { name: 'Construction Revenue', amount: 4200000 }, 
        { name: 'Design Services', amount: 180000 }, 
        { name: 'Project Management', amount: 320000 }
      ]
    },
    { 
      category: 'Cost of Goods Sold', 
      items: [
        { name: 'Materials Cost', amount: 1800000 }, 
        { name: 'Labor Cost', amount: 1200000 }, 
        { name: 'Subcontractor Costs', amount: 950000 }
      ]
    },
    { 
      category: 'Operating Expenses', 
      items: [
        { name: 'Equipment Rental', amount: 180000 }, 
        { name: 'Office Rent', amount: 48000 }, 
        { name: 'Insurance', amount: 85000 }, 
        { name: 'Fuel & Transportation', amount: 35000 }
      ]
    }
  ];

  const handlePrint = () => {
    setShowPrintDialog(true);
    setTimeout(() => {
      window.print();
      setShowPrintDialog(false);
    }, 100);
  };

  const handleExportPDF = () => {
    setShowExportDialog(true);
    setTimeout(() => {
      setShowExportDialog(false);
      // Simulate PDF download
      const link = document.createElement('a');
      link.href = '#';
      link.download = `${reports.find(r => r.id === selectedReport)?.name.replace(' ', '_')}_${reportPeriod}.pdf`;
      link.click();
    }, 1500);
  };

  const handleExportExcel = () => {
    setShowExportDialog(true);
    setTimeout(() => {
      setShowExportDialog(false);
      // Simulate Excel download
      const link = document.createElement('a');
      link.href = '#';
      link.download = `${reports.find(r => r.id === selectedReport)?.name.replace(' ', '_')}_${reportPeriod}.xlsx`;
      link.click();
    }, 1500);
  };

  const renderBalanceSheet = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Assets</h3>
        <div className="space-y-6">
          {balanceSheetData.assets.map((section, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-3">{section.name}</h4>
              <div className="space-y-2">
                {section.items.map((item, itemIndex) => (
                  <div key={itemIndex} className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">{item.name}</span>
                    <span className={`font-medium ${item.amount < 0 ? 'text-red-600' : 'text-gray-900'}`}>
                      ${Math.abs(item.amount).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-200 mt-3 pt-3">
                <div className="flex items-center justify-between font-medium">
                  <span>Total {section.name}</span>
                  <span>${section.items.reduce((sum, item) => sum + item.amount, 0).toLocaleString()}</span>
                </div>
              </div>
            </div>
          ))}
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="flex items-center justify-between font-semibold text-lg">
              <span>Total Assets</span>
              <span className="text-blue-700">
                ${balanceSheetData.assets.reduce((sum, section) => 
                  sum + section.items.reduce((itemSum, item) => itemSum + item.amount, 0), 0
                ).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Liabilities & Equity</h3>
        <div className="space-y-6">
          {balanceSheetData.liabilities.map((section, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-3">{section.name}</h4>
              <div className="space-y-2">
                {section.items.map((item, itemIndex) => (
                  <div key={itemIndex} className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">{item.name}</span>
                    <span className="font-medium text-gray-900">${item.amount.toLocaleString()}</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-200 mt-3 pt-3">
                <div className="flex items-center justify-between font-medium">
                  <span>Total {section.name}</span>
                  <span>${section.items.reduce((sum, item) => sum + item.amount, 0).toLocaleString()}</span>
                </div>
              </div>
            </div>
          ))}
          
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 mb-3">Equity</h4>
            <div className="space-y-2">
              {balanceSheetData.equity.map((item, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <span className="text-gray-700">{item.name}</span>
                  <span className="font-medium text-gray-900">${item.amount.toLocaleString()}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-200 mt-3 pt-3">
              <div className="flex items-center justify-between font-medium">
                <span>Total Equity</span>
                <span>${balanceSheetData.equity.reduce((sum, item) => sum + item.amount, 0).toLocaleString()}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-red-50 rounded-lg p-4 border border-red-200">
            <div className="flex items-center justify-between font-semibold text-lg">
              <span>Total Liabilities & Equity</span>
              <span className="text-red-700">
                ${(
                  balanceSheetData.liabilities.reduce((sum, section) => 
                    sum + section.items.reduce((itemSum, item) => itemSum + item.amount, 0), 0
                  ) + balanceSheetData.equity.reduce((sum, item) => sum + item.amount, 0)
                ).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderIncomeStatement = () => (
    <div className="max-w-2xl">
      <div className="space-y-6">
        {incomeStatementData.map((section, index) => (
          <div key={index} className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 mb-3">{section.category}</h4>
            <div className="space-y-2">
              {section.items.map((item, itemIndex) => (
                <div key={itemIndex} className="flex items-center justify-between text-sm">
                  <span className="text-gray-700">{item.name}</span>
                  <span className="font-medium text-gray-900">${item.amount.toLocaleString()}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-200 mt-3 pt-3">
              <div className="flex items-center justify-between font-medium">
                <span>Total {section.category}</span>
                <span>${section.items.reduce((sum, item) => sum + item.amount, 0).toLocaleString()}</span>
              </div>
            </div>
          </div>
        ))}
        
        <div className="bg-green-50 rounded-lg p-4 border border-green-200">
          <div className="space-y-2">
            <div className="flex items-center justify-between font-medium text-lg">
              <span>Gross Profit</span>
              <span className="text-green-700">$1,250,000</span>
            </div>
            <div className="flex items-center justify-between font-semibold text-xl">
              <span>Net Income</span>
              <span className="text-green-700">$902,000</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {showPrintDialog && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-xl">
            <div className="flex items-center space-x-3">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span className="text-gray-900">Preparing report for printing...</span>
            </div>
          </div>
        </div>
      )}

      {showExportDialog && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-xl">
            <div className="flex items-center space-x-3">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-600"></div>
              <span className="text-gray-900">Exporting report...</span>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {reports.map((report) => (
            <button
              key={report.id}
              onClick={() => setSelectedReport(report.id)}
              className={`p-4 border rounded-lg text-left transition-all ${
                selectedReport === report.id
                  ? 'border-blue-300 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center space-x-2 mb-2">
                <i className={`${report.icon} w-5 h-5 flex items-center justify-center text-blue-600`}></i>
                <h4 className="font-medium text-gray-900">{report.name}</h4>
              </div>
              <p className="text-xs text-gray-600">{report.description}</p>
            </button>
          ))}
        </div>
        
        <div className="flex items-center space-x-3">
          <select
            value={reportPeriod}
            onChange={(e) => setReportPeriod(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            <option value="current">Current Period</option>
            <option value="previous">Previous Period</option>
            <option value="ytd">Year to Date</option>
            <option value="custom">Custom Range</option>
          </select>
          <button 
            onClick={handlePrint}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap"
          >
            <i className="ri-printer-line w-4 h-4 flex items-center justify-center"></i>
            <span>Print</span>
          </button>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-semibold text-gray-900">
              {reports.find(r => r.id === selectedReport)?.name}
            </h3>
            <p className="text-sm text-gray-600 mt-1">
              Period: January 1, 2024 - January 31, 2024
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <button 
              onClick={handleExportPDF}
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-white whitespace-nowrap"
            >
              <i className="ri-download-line w-4 h-4 flex items-center justify-center"></i>
              <span className="text-sm">Export PDF</span>
            </button>
            <button 
              onClick={handleExportExcel}
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-white whitespace-nowrap"
            >
              <i className="ri-file-excel-line w-4 h-4 flex items-center justify-center"></i>
              <span className="text-sm">Export Excel</span>
            </button>
          </div>
        </div>

        {selectedReport === 'balance-sheet' && renderBalanceSheet()}
        {selectedReport === 'income-statement' && renderIncomeStatement()}
        {selectedReport !== 'balance-sheet' && selectedReport !== 'income-statement' && (
          <div className="text-center py-12">
            <i className="ri-file-chart-line w-16 h-16 flex items-center justify-center text-gray-400 mx-auto mb-4"></i>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Report Under Development</h3>
            <p className="text-gray-600">This report is being prepared and will be available soon.</p>
          </div>
        )}
      </div>
    </div>
  );
}
