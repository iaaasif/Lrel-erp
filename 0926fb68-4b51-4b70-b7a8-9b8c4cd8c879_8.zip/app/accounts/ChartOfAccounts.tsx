'use client';

import { useState } from 'react';

interface Account {
  id: string;
  code: string;
  name: string;
  type: 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense';
  balance: number;
  description: string;
  isActive: boolean;
}

const accounts: Account[] = [
  // Assets
  { id: '1', code: '1000', name: 'Cash - Operating', type: 'Asset', balance: 450000, description: 'Main operating cash account', isActive: true },
  { id: '2', code: '1010', name: 'Cash - Payroll', type: 'Asset', balance: 125000, description: 'Dedicated payroll account', isActive: true },
  { id: '3', code: '1100', name: 'Accounts Receivable', type: 'Asset', balance: 850000, description: 'Outstanding client payments', isActive: true },
  { id: '4', code: '1200', name: 'Inventory - Materials', type: 'Asset', balance: 320000, description: 'Construction materials inventory', isActive: true },
  { id: '5', code: '1300', name: 'Equipment', type: 'Asset', balance: 2500000, description: 'Construction equipment and machinery', isActive: true },
  { id: '6', code: '1400', name: 'Vehicles', type: 'Asset', balance: 680000, description: 'Company vehicles and trucks', isActive: true },
  
  // Liabilities
  { id: '7', code: '2000', name: 'Accounts Payable', type: 'Liability', balance: 280000, description: 'Outstanding supplier payments', isActive: true },
  { id: '8', code: '2100', name: 'Accrued Payroll', type: 'Liability', balance: 95000, description: 'Unpaid employee wages', isActive: true },
  { id: '9', code: '2200', name: 'Equipment Loans', type: 'Liability', balance: 1200000, description: 'Equipment financing loans', isActive: true },
  { id: '10', code: '2300', name: 'Line of Credit', type: 'Liability', balance: 350000, description: 'Business line of credit', isActive: true },
  
  // Equity
  { id: '11', code: '3000', name: 'Owner\'s Equity', type: 'Equity', balance: 3800000, description: 'Owner\'s investment in business', isActive: true },
  { id: '12', code: '3100', name: 'Retained Earnings', type: 'Equity', balance: 1850000, description: 'Accumulated business profits', isActive: true },
  
  // Revenue
  { id: '13', code: '4000', name: 'Construction Revenue', type: 'Revenue', balance: 4200000, description: 'Revenue from construction projects', isActive: true },
  { id: '14', code: '4100', name: 'Design Services', type: 'Revenue', balance: 180000, description: 'Architectural and design services', isActive: true },
  { id: '15', code: '4200', name: 'Project Management', type: 'Revenue', balance: 320000, description: 'Project management fees', isActive: true },
  
  // Expenses
  { id: '16', code: '5000', name: 'Materials Cost', type: 'Expense', balance: 1800000, description: 'Cost of construction materials', isActive: true },
  { id: '17', code: '5100', name: 'Labor Cost', type: 'Expense', balance: 1200000, description: 'Direct labor costs', isActive: true },
  { id: '18', code: '5200', name: 'Subcontractor Costs', type: 'Expense', balance: 950000, description: 'Subcontractor payments', isActive: true },
  { id: '19', code: '5300', name: 'Equipment Rental', type: 'Expense', balance: 180000, description: 'Equipment rental expenses', isActive: true },
  { id: '20', code: '6000', name: 'Office Rent', type: 'Expense', balance: 48000, description: 'Office space rental', isActive: true },
  { id: '21', code: '6100', name: 'Insurance', type: 'Expense', balance: 85000, description: 'Business insurance premiums', isActive: true },
  { id: '22', code: '6200', name: 'Fuel & Transportation', type: 'Expense', balance: 35000, description: 'Vehicle fuel and transportation', isActive: true }
];

const typeColors = {
  Asset: 'bg-blue-100 text-blue-800',
  Liability: 'bg-red-100 text-red-800',
  Equity: 'bg-purple-100 text-purple-800',
  Revenue: 'bg-green-100 text-green-800',
  Expense: 'bg-orange-100 text-orange-800'
};

export default function ChartOfAccounts() {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredAccounts = accounts.filter(account => {
    const matchesType = selectedType === 'all' || account.type === selectedType;
    const matchesSearch = account.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         account.code.includes(searchTerm) ||
                         account.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  const accountTypes = ['Asset', 'Liability', 'Equity', 'Revenue', 'Expense'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center text-gray-400"></i>
            <input
              type="text"
              placeholder="Search accounts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setSelectedType('all')}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                selectedType === 'all' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              All
            </button>
            {accountTypes.map((type) => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                  selectedType === type ? typeColors[type as keyof typeof typeColors] : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>
        
        <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
          <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
          <span>Add Account</span>
        </button>
      </div>

      <div className="bg-gray-50 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white border-b border-gray-200">
              <tr>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Account Code</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Account Name</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Type</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Balance</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Description</th>
                <th className="text-center py-4 px-6 font-medium text-gray-900">Status</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {filteredAccounts.map((account) => (
                <tr key={account.id} className="hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <span className="font-mono text-sm font-medium text-gray-900">{account.code}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="font-medium text-gray-900">{account.name}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${typeColors[account.type]}`}>
                      {account.type}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <span className={`font-medium ${
                      account.type === 'Asset' || account.type === 'Expense' 
                        ? account.balance > 0 ? 'text-gray-900' : 'text-red-600'
                        : account.balance > 0 ? 'text-green-600' : 'text-gray-900'
                    }`}>
                      ${account.balance.toLocaleString()}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-600">{account.description}</span>
                  </td>
                  <td className="py-4 px-6 text-center">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                      account.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {account.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center justify-end space-x-2">
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <i className="ri-eye-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <i className="ri-edit-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-red-600 hover:bg-red-50 rounded">
                        <i className="ri-delete-bin-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}