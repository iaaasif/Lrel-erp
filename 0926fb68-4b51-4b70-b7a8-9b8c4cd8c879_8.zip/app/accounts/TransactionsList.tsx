'use client';

import { useState } from 'react';

interface Transaction {
  id: string;
  date: string;
  reference: string;
  description: string;
  account: string;
  debit: number;
  credit: number;
  balance: number;
  type: 'payment' | 'receipt' | 'journal' | 'adjustment';
  status: 'cleared' | 'pending' | 'reconciled';
  project?: string;
}

const transactions: Transaction[] = [
  {
    id: '1',
    date: '2024-01-15',
    reference: 'CHK-001245',
    description: 'Steel Purchase - Ocean View Project',
    account: 'Materials Cost (5000)',
    debit: 85000,
    credit: 0,
    balance: 85000,
    type: 'payment',
    status: 'cleared',
    project: 'Ocean View Towers'
  },
  {
    id: '2',
    date: '2024-01-15',
    reference: 'CHK-001245',
    description: 'Steel Purchase - Ocean View Project',
    account: 'Cash - Operating (1000)',
    debit: 0,
    credit: 85000,
    balance: -85000,
    type: 'payment',
    status: 'cleared',
    project: 'Ocean View Towers'
  },
  {
    id: '3',
    date: '2024-01-14',
    reference: 'INV-2024-001',
    description: 'Progress Payment - Sunset Residences',
    account: 'Cash - Operating (1000)',
    debit: 450000,
    credit: 0,
    balance: 450000,
    type: 'receipt',
    status: 'cleared',
    project: 'Sunset Residences'
  },
  {
    id: '4',
    date: '2024-01-14',
    reference: 'INV-2024-001',
    description: 'Progress Payment - Sunset Residences',
    account: 'Accounts Receivable (1100)',
    debit: 0,
    credit: 450000,
    balance: -450000,
    type: 'receipt',
    status: 'cleared',
    project: 'Sunset Residences'
  },
  {
    id: '5',
    date: '2024-01-12',
    reference: 'CHK-001244',
    description: 'Equipment Rental - Crane Service',
    account: 'Equipment Rental (5300)',
    debit: 25000,
    credit: 0,
    balance: 25000,
    type: 'payment',
    status: 'pending',
    project: 'City Mall Extension'
  },
  {
    id: '6',
    date: '2024-01-12',
    reference: 'CHK-001244',
    description: 'Equipment Rental - Crane Service',
    account: 'Cash - Operating (1000)',
    debit: 0,
    credit: 25000,
    balance: -25000,
    type: 'payment',
    status: 'pending',
    project: 'City Mall Extension'
  },
  {
    id: '7',
    date: '2024-01-10',
    reference: 'CHK-001243',
    description: 'Subcontractor Payment - Electrical Work',
    account: 'Subcontractor Costs (5200)',
    debit: 120000,
    credit: 0,
    balance: 120000,
    type: 'payment',
    status: 'reconciled',
    project: 'Ocean View Towers'
  },
  {
    id: '8',
    date: '2024-01-10',
    reference: 'CHK-001243',
    description: 'Subcontractor Payment - Electrical Work',
    account: 'Cash - Operating (1000)',
    debit: 0,
    credit: 120000,
    balance: -120000,
    type: 'payment',
    status: 'reconciled',
    project: 'Ocean View Towers'
  }
];

const typeColors = {
  payment: 'bg-red-100 text-red-800',
  receipt: 'bg-green-100 text-green-800',
  journal: 'bg-blue-100 text-blue-800',
  adjustment: 'bg-yellow-100 text-yellow-800'
};

const statusColors = {
  cleared: 'bg-green-100 text-green-800',
  pending: 'bg-yellow-100 text-yellow-800',
  reconciled: 'bg-blue-100 text-blue-800'
};

export default function TransactionsList() {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState('30');

  const filteredTransactions = transactions.filter(transaction => {
    const matchesType = selectedType === 'all' || transaction.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || transaction.status === selectedStatus;
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.account.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center text-gray-400"></i>
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            <option value="all">All Types</option>
            <option value="payment">Payments</option>
            <option value="receipt">Receipts</option>
            <option value="journal">Journal Entries</option>
            <option value="adjustment">Adjustments</option>
          </select>
          
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="cleared">Cleared</option>
            <option value="reconciled">Reconciled</option>
          </select>
          
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
            <option value="365">Last year</option>
          </select>
        </div>
        
        <div className="flex items-center space-x-3">
          <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap">
            <i className="ri-download-line w-4 h-4 flex items-center justify-center"></i>
            <span className="text-sm">Export</span>
          </button>
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
            <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
            <span>New Entry</span>
          </button>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white border-b border-gray-200">
              <tr>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Date</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Reference</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Description</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Account</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Debit</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Credit</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Type</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Status</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {filteredTransactions.map((transaction) => (
                <tr key={transaction.id} className="hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{transaction.date}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-mono text-gray-900">{transaction.reference}</span>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{transaction.description}</p>
                      {transaction.project && (
                        <p className="text-xs text-gray-600">Project: {transaction.project}</p>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{transaction.account}</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    {transaction.debit > 0 && (
                      <span className="text-sm font-medium text-gray-900">
                        ${transaction.debit.toLocaleString()}
                      </span>
                    )}
                  </td>
                  <td className="py-4 px-6 text-right">
                    {transaction.credit > 0 && (
                      <span className="text-sm font-medium text-gray-900">
                        ${transaction.credit.toLocaleString()}
                      </span>
                    )}
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${typeColors[transaction.type]}`}>
                      {transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1)}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusColors[transaction.status]}`}>
                      {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center justify-end space-x-2">
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <i className="ri-eye-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <i className="ri-edit-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-green-600 hover:bg-green-50 rounded">
                        <i className="ri-printer-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex items-center justify-between text-sm text-gray-600">
        <div>
          Showing {filteredTransactions.length} of {transactions.length} transactions
        </div>
        <div className="flex items-center space-x-2">
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 whitespace-nowrap">
            Previous
          </button>
          <span className="px-3 py-1">1 of 3</span>
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 whitespace-nowrap">
            Next
          </button>
        </div>
      </div>
    </div>
  );
}