
'use client';

import { useState } from 'react';

interface Requisition {
  id: string;
  reqNumber: string;
  requestDate: string;
  requiredBy: string;
  requestedBy: string;
  project: string;
  department: string;
  totalItems: number;
  estimatedValue: number;
  status: 'Draft' | 'Submitted' | 'Under Review' | 'Approved' | 'Rejected' | 'Converted';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  approver?: string;
  lastUpdated: string;
}

const requisitions: Requisition[] = [
  {
    id: '1',
    reqNumber: 'REQ-2024-001',
    requestDate: '2024-01-15',
    requiredBy: '2024-01-25',
    requestedBy: 'John Mitchell',
    project: 'Ocean View Towers',
    department: 'Construction',
    totalItems: 5,
    estimatedValue: 125000,
    status: 'Under Review',
    priority: 'High',
    approver: 'Sarah Johnson',
    lastUpdated: '2024-01-15 14:30'
  },
  {
    id: '2',
    reqNumber: 'REQ-2024-002',
    requestDate: '2024-01-14',
    requiredBy: '2024-01-28',
    requestedBy: 'Mike Davis',
    project: 'Sunset Residences',
    department: 'Engineering',
    totalItems: 3,
    estimatedValue: 68500,
    status: 'Approved',
    priority: 'Medium',
    approver: 'Robert Wilson',
    lastUpdated: '2024-01-14 16:45'
  },
  {
    id: '3',
    reqNumber: 'REQ-2024-003',
    requestDate: '2024-01-13',
    requiredBy: '2024-01-20',
    requestedBy: 'Lisa Chen',
    project: 'City Mall Extension',
    department: 'Safety',
    totalItems: 8,
    estimatedValue: 15750,
    status: 'Converted',
    priority: 'Critical',
    approver: 'Sarah Johnson',
    lastUpdated: '2024-01-13 11:20'
  },
  {
    id: '4',
    reqNumber: 'REQ-2024-004',
    requestDate: '2024-01-12',
    requiredBy: '2024-02-01',
    requestedBy: 'David Brown',
    project: 'Industrial Complex',
    department: 'Procurement',
    totalItems: 12,
    estimatedValue: 245000,
    status: 'Submitted',
    priority: 'High',
    lastUpdated: '2024-01-12 09:15'
  },
  {
    id: '5',
    reqNumber: 'REQ-2024-005',
    requestDate: '2024-01-11',
    requiredBy: '2024-01-30',
    requestedBy: 'Emma Wilson',
    project: 'Residential Tower B',
    department: 'Quality Control',
    totalItems: 2,
    estimatedValue: 8900,
    status: 'Rejected',
    priority: 'Low',
    approver: 'Robert Wilson',
    lastUpdated: '2024-01-11 13:45'
  },
  {
    id: '6',
    reqNumber: 'REQ-2024-006',
    requestDate: '2024-01-10',
    requiredBy: '2024-01-22',
    requestedBy: 'Alex Turner',
    project: 'Ocean View Towers',
    department: 'Construction',
    totalItems: 6,
    estimatedValue: 89500,
    status: 'Draft',
    priority: 'Medium',
    lastUpdated: '2024-01-10 17:30'
  }
];

const statusColors = {
  'Draft': 'bg-gray-100 text-gray-800',
  'Submitted': 'bg-blue-100 text-blue-800',
  'Under Review': 'bg-yellow-100 text-yellow-800',
  'Approved': 'bg-green-100 text-green-800',
  'Rejected': 'bg-red-100 text-red-800',
  'Converted': 'bg-purple-100 text-purple-800'
};

const priorityColors = {
  'Low': 'bg-green-100 text-green-800',
  'Medium': 'bg-yellow-100 text-yellow-800',
  'High': 'bg-orange-100 text-orange-800',
  'Critical': 'bg-red-100 text-red-800'
};

export default function RequisitionsList() {
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [selectedPriority, setSelectedPriority] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState('30');

  const statusOptions = ['All', 'Draft', 'Submitted', 'Under Review', 'Approved', 'Rejected', 'Converted'];
  const priorityOptions = ['All', 'Low', 'Medium', 'High', 'Critical'];

  const filteredRequisitions = requisitions.filter(req => {
    const matchesStatus = selectedStatus === 'All' || req.status === selectedStatus;
    const matchesPriority = selectedPriority === 'All' || req.priority === selectedPriority;
    const matchesSearch = req.reqNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         req.requestedBy.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         req.project.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesPriority && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center text-gray-400"></i>
            <input
              type="text"
              placeholder="Search requisitions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            {statusOptions.map(status => (
              <option key={status} value={status}>{status === 'All' ? 'All Status' : status}</option>
            ))}
          </select>
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            {priorityOptions.map(priority => (
              <option key={priority} value={priority}>{priority === 'All' ? 'All Priority' : priority}</option>
            ))}
          </select>
        </div>
        <div className="flex items-center space-x-3">
          <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap">
            <i className="ri-download-line w-4 h-4 flex items-center justify-center"></i>
            <span className="text-sm">Export</span>
          </button>
          <button 
            onClick={() => {
              // Get the parent component's setActiveTab function
              const event = new CustomEvent('switchToNewRequisition');
              window.dispatchEvent(event);
            }}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap"
          >
            <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
            <span>New Requisition</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Requisitions</p>
              <p className="text-2xl font-bold text-gray-900">{requisitions.length}</p>
            </div>
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <i className="ri-file-list-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending Review</p>
              <p className="text-2xl font-bold text-gray-900">
                {requisitions.filter(r => r.status === 'Under Review' || r.status === 'Submitted').length}
              </p>
            </div>
            <div className="w-10 h-10 bg-yellow-600 rounded-lg flex items-center justify-center">
              <i className="ri-time-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Approved</p>
              <p className="text-2xl font-bold text-gray-900">
                {requisitions.filter(r => r.status === 'Approved').length}
              </p>
            </div>
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
              <i className="ri-check-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Value</p>
              <p className="text-2xl font-bold text-gray-900">
                ${requisitions.reduce((sum, r) => sum + r.estimatedValue, 0).toLocaleString()}
              </p>
            </div>
            <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
              <i className="ri-money-dollar-circle-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white border-b border-gray-200">
              <tr>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Requisition #</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Requested By</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Project</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Required By</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Items</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Est. Value</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Priority</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Status</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {filteredRequisitions.map((req) => (
                <tr key={req.id} className="hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <div>
                      <span className="font-mono text-sm font-medium text-gray-900">{req.reqNumber}</span>
                      <p className="text-xs text-gray-600">{req.requestDate}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <span className="text-sm font-medium text-gray-900">{req.requestedBy}</span>
                      <p className="text-xs text-gray-600">{req.department}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{req.project}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{req.requiredBy}</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <span className="text-sm text-gray-900">{req.totalItems}</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <span className="text-sm font-medium text-gray-900">${req.estimatedValue.toLocaleString()}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${priorityColors[req.priority]}`}>
                      {req.priority}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusColors[req.status]}`}>
                      {req.status}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center justify-end space-x-2">
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <i className="ri-eye-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <i className="ri-edit-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-green-600 hover:bg-green-50 rounded">
                        <i className="ri-printer-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex items-center justify-between text-sm text-gray-600">
        <div>
          Showing {filteredRequisitions.length} of {requisitions.length} requisitions
        </div>
        <div className="flex items-center space-x-2">
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 whitespace-nowrap">
            Previous
          </button>
          <span className="px-3 py-1">1 of 1</span>
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 whitespace-nowrap">
            Next
          </button>
        </div>
      </div>
    </div>
  );
}
