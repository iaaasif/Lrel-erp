'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import RequisitionForm from './RequisitionForm';
import RequisitionsList from './RequisitionsList';
import ApprovalWorkflow from './ApprovalWorkflow';

export default function PurchaseRequisitionPage() {
  const [activeTab, setActiveTab] = useState('list');

  const tabs = [
    { id: 'list', label: 'All Requisitions', icon: 'ri-list-check-line' },
    { id: 'new', label: 'New Requisition', icon: 'ri-add-line' },
    { id: 'approval', label: 'Approval Workflow', icon: 'ri-check-double-line' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Purchase Requisition</h1>
            <p className="text-gray-600">Create and manage purchase requests for materials and services</p>
          </div>
          
          <div className="flex items-center space-x-3">
            <button className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2 whitespace-nowrap">
              <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
              <span>Quick Request</span>
            </button>
            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
              <i className="ri-download-line w-4 h-4 flex items-center justify-center"></i>
              <span>Export Report</span>
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <i className={`${tab.icon} w-4 h-4 flex items-center justify-center`}></i>
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>
          
          <div className="p-6">
            {activeTab === 'list' && <RequisitionsList />}
            {activeTab === 'new' && <RequisitionForm />}
            {activeTab === 'approval' && <ApprovalWorkflow />}
          </div>
        </div>
      </main>
    </div>
  );
}