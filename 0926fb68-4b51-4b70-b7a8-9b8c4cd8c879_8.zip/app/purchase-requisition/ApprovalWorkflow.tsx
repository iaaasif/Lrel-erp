'use client';

import { useState } from 'react';

interface ApprovalStep {
  id: string;
  stepName: string;
  approver: string;
  role: string;
  minAmount?: number;
  maxAmount?: number;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Not Started';
  approvedDate?: string;
  comments?: string;
}

interface WorkflowRequisition {
  id: string;
  reqNumber: string;
  requestedBy: string;
  project: string;
  totalValue: number;
  submittedDate: string;
  currentStep: number;
  steps: ApprovalStep[];
}

const workflowRequisitions: WorkflowRequisition[] = [
  {
    id: '1',
    reqNumber: 'REQ-2024-001',
    requestedBy: 'John Mitchell',
    project: 'Ocean View Towers',
    totalValue: 125000,
    submittedDate: '2024-01-15',
    currentStep: 1,
    steps: [
      {
        id: '1',
        stepName: 'Department Manager Review',
        approver: 'Sarah Johnson',
        role: 'Construction Manager',
        maxAmount: 50000,
        status: 'Approved',
        approvedDate: '2024-01-15',
        comments: 'Materials urgently needed for foundation work'
      },
      {
        id: '2',
        stepName: 'Procurement Manager Review',
        approver: 'Robert Wilson',
        role: 'Procurement Manager',
        maxAmount: 200000,
        status: 'Pending',
        comments: ''
      },
      {
        id: '3',
        stepName: 'Finance Director Approval',
        approver: 'Lisa Chen',
        role: 'Finance Director',
        minAmount: 100000,
        status: 'Not Started',
        comments: ''
      }
    ]
  },
  {
    id: '2',
    reqNumber: 'REQ-2024-004',
    requestedBy: 'David Brown',
    project: 'Industrial Complex',
    totalValue: 245000,
    submittedDate: '2024-01-12',
    currentStep: 2,
    steps: [
      {
        id: '1',
        stepName: 'Department Manager Review',
        approver: 'Mike Davis',
        role: 'Engineering Manager',
        maxAmount: 50000,
        status: 'Approved',
        approvedDate: '2024-01-12',
        comments: 'Critical equipment for project timeline'
      },
      {
        id: '2',
        stepName: 'Procurement Manager Review',
        approver: 'Robert Wilson',
        role: 'Procurement Manager',
        maxAmount: 200000,
        status: 'Approved',
        approvedDate: '2024-01-13',
        comments: 'Suppliers verified, pricing competitive'
      },
      {
        id: '3',
        stepName: 'Finance Director Approval',
        approver: 'Lisa Chen',
        role: 'Finance Director',
        minAmount: 100000,
        status: 'Pending',
        comments: ''
      },
      {
        id: '4',
        stepName: 'CEO Final Approval',
        approver: 'Alex Turner',
        role: 'Chief Executive Officer',
        minAmount: 200000,
        status: 'Not Started',
        comments: ''
      }
    ]
  }
];

const stepStatusColors = {
  'Pending': 'bg-yellow-100 text-yellow-800 border-yellow-300',
  'Approved': 'bg-green-100 text-green-800 border-green-300',
  'Rejected': 'bg-red-100 text-red-800 border-red-300',
  'Not Started': 'bg-gray-100 text-gray-600 border-gray-300'
};

export default function ApprovalWorkflow() {
  const [selectedRequisition, setSelectedRequisition] = useState<string | null>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject' | null>(null);
  const [comments, setComments] = useState('');

  const handleApprovalAction = (reqId: string, stepId: string, action: 'approve' | 'reject') => {
    console.log('Approval action:', { reqId, stepId, action, comments });
    setActionType(null);
    setComments('');
    setSelectedRequisition(null);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gray-50 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending My Review</p>
              <p className="text-2xl font-bold text-gray-900">2</p>
            </div>
            <div className="w-10 h-10 bg-yellow-600 rounded-lg flex items-center justify-center">
              <i className="ri-time-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Approved This Week</p>
              <p className="text-2xl font-bold text-gray-900">8</p>
            </div>
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
              <i className="ri-check-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Average Approval Time</p>
              <p className="text-2xl font-bold text-gray-900">2.3 days</p>
            </div>
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <i className="ri-timer-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {workflowRequisitions.map((req) => (
          <div key={req.id} className="bg-gray-50 rounded-lg border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{req.reqNumber}</h3>
                  <div className="mt-2 space-y-1">
                    <p className="text-sm text-gray-600">Requested by: <span className="font-medium">{req.requestedBy}</span></p>
                    <p className="text-sm text-gray-600">Project: <span className="font-medium">{req.project}</span></p>
                    <p className="text-sm text-gray-600">Total Value: <span className="font-medium">${req.totalValue.toLocaleString()}</span></p>
                    <p className="text-sm text-gray-600">Submitted: <span className="font-medium">{req.submittedDate}</span></p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600">Step {req.currentStep + 1} of {req.steps.length}</span>
                  <button className="text-blue-600 hover:text-blue-700 text-sm font-medium whitespace-nowrap">
                    View Details
                  </button>
                </div>
              </div>
            </div>

            <div className="p-6">
              <div className="space-y-4">
                {req.steps.map((step, index) => (
                  <div key={step.id} className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${
                        step.status === 'Approved' ? 'bg-green-100 border-green-300' :
                        step.status === 'Rejected' ? 'bg-red-100 border-red-300' :
                        step.status === 'Pending' ? 'bg-yellow-100 border-yellow-300' :
                        'bg-gray-100 border-gray-300'
                      }`}>
                        {step.status === 'Approved' && (
                          <i className="ri-check-line w-4 h-4 flex items-center justify-center text-green-600"></i>
                        )}
                        {step.status === 'Rejected' && (
                          <i className="ri-close-line w-4 h-4 flex items-center justify-center text-red-600"></i>
                        )}
                        {step.status === 'Pending' && (
                          <i className="ri-time-line w-4 h-4 flex items-center justify-center text-yellow-600"></i>
                        )}
                        {step.status === 'Not Started' && (
                          <span className="text-gray-400 text-xs font-bold">{index + 1}</span>
                        )}
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="text-sm font-medium text-gray-900">{step.stepName}</h4>
                          <p className="text-sm text-gray-600">{step.approver} • {step.role}</p>
                          {step.minAmount && step.maxAmount && (
                            <p className="text-xs text-gray-500">
                              Authority: ${step.minAmount?.toLocaleString()} - ${step.maxAmount?.toLocaleString()}
                            </p>
                          )}
                          {step.maxAmount && !step.minAmount && (
                            <p className="text-xs text-gray-500">
                              Authority: Up to ${step.maxAmount?.toLocaleString()}
                            </p>
                          )}
                          {step.minAmount && !step.maxAmount && (
                            <p className="text-xs text-gray-500">
                              Authority: Above ${step.minAmount?.toLocaleString()}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full border ${stepStatusColors[step.status]}`}>
                            {step.status}
                          </span>
                          {step.status === 'Pending' && (
                            <div className="flex items-center space-x-1">
                              <button
                                onClick={() => {
                                  setSelectedRequisition(req.id);
                                  setActionType('approve');
                                }}
                                className="bg-green-600 text-white px-3 py-1 rounded text-xs hover:bg-green-700 whitespace-nowrap"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => {
                                  setSelectedRequisition(req.id);
                                  setActionType('reject');
                                }}
                                className="bg-red-600 text-white px-3 py-1 rounded text-xs hover:bg-red-700 whitespace-nowrap"
                              >
                                Reject
                              </button>
                            </div>
                          )}
                        </div>
                      </div>

                      {step.approvedDate && (
                        <p className="text-xs text-gray-500 mt-1">
                          {step.status === 'Approved' ? 'Approved' : 'Rejected'} on {step.approvedDate}
                        </p>
                      )}

                      {step.comments && (
                        <div className="mt-2 p-2 bg-white rounded border border-gray-200">
                          <p className="text-sm text-gray-700">{step.comments}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {selectedRequisition && actionType && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {actionType === 'approve' ? 'Approve Requisition' : 'Reject Requisition'}
            </h3>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Comments {actionType === 'reject' ? '(Required)' : '(Optional)'}
              </label>
              <textarea
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={3}
                placeholder={`Add your ${actionType === 'approve' ? 'approval' : 'rejection'} comments...`}
                maxLength={500}
                required={actionType === 'reject'}
              />
              <p className="text-xs text-gray-500 mt-1">
                {comments.length}/500 characters
              </p>
            </div>

            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => {
                  setSelectedRequisition(null);
                  setActionType(null);
                  setComments('');
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 whitespace-nowrap"
              >
                Cancel
              </button>
              <button
                onClick={() => handleApprovalAction(selectedRequisition, '1', actionType)}
                className={`px-4 py-2 rounded-lg text-white whitespace-nowrap ${
                  actionType === 'approve' 
                    ? 'bg-green-600 hover:bg-green-700' 
                    : 'bg-red-600 hover:bg-red-700'
                }`}
                disabled={actionType === 'reject' && !comments.trim()}
              >
                Confirm {actionType === 'approve' ? 'Approval' : 'Rejection'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}