'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import Link from 'next/link';

interface Project {
  id: string;
  name: string;
  location: string;
  status: 'active' | 'completed' | 'on-hold' | 'planning';
  progress: number;
  budget: string;
  startDate: string;
  endDate: string;
  manager: string;
  team: number;
}

const projects: Project[] = [
  {
    id: '1',
    name: 'Ocean View Towers',
    location: 'Downtown District, Miami FL',
    status: 'active',
    progress: 85,
    budget: '$2,400,000',
    startDate: '2024-01-15',
    endDate: '2024-12-30',
    manager: 'John Smith',
    team: 45
  },
  {
    id: '2',
    name: 'Sunset Residences',
    location: 'Westside Area, Phoenix AZ',
    status: 'active',
    progress: 92,
    budget: '$1,800,000',
    startDate: '2023-08-20',
    endDate: '2024-06-15',
    manager: 'Sarah Johnson',
    team: 32
  },
  {
    id: '3',
    name: 'City Mall Extension',
    location: 'Commercial Hub, Dallas TX',
    status: 'active',
    progress: 67,
    budget: '$3,200,000',
    startDate: '2024-03-10',
    endDate: '2025-02-28',
    manager: 'Mike Davis',
    team: 68
  },
  {
    id: '4',
    name: 'Green Valley Homes',
    location: 'Suburban Area, Austin TX',
    status: 'completed',
    progress: 100,
    budget: '$1,500,000',
    startDate: '2023-05-01',
    endDate: '2024-01-30',
    manager: 'Lisa Chen',
    team: 28
  },
  {
    id: '5',
    name: 'Tech Campus Building',
    location: 'Innovation District, Seattle WA',
    status: 'planning',
    progress: 15,
    budget: '$4,500,000',
    startDate: '2024-06-01',
    endDate: '2025-08-30',
    manager: 'Robert Wilson',
    team: 12
  }
];

const statusColors = {
  active: 'bg-green-100 text-green-800',
  completed: 'bg-blue-100 text-blue-800',
  'on-hold': 'bg-red-100 text-red-800',
  planning: 'bg-yellow-100 text-yellow-800'
};

export default function ProjectsPage() {
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProjects = projects.filter(project => {
    const matchesStatus = selectedStatus === 'all' || project.status === selectedStatus;
    const matchesSearch = project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Project Management</h1>
            <p className="text-gray-600">Monitor and manage all construction projects</p>
          </div>
          
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
            <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
            <span>New Project</span>
          </button>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center text-gray-400"></i>
                <input
                  type="text"
                  placeholder="Search projects..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setSelectedStatus('all')}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                    selectedStatus === 'all' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setSelectedStatus('active')}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                    selectedStatus === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  Active
                </button>
                <button
                  onClick={() => setSelectedStatus('completed')}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                    selectedStatus === 'completed' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  Completed
                </button>
                <button
                  onClick={() => setSelectedStatus('planning')}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                    selectedStatus === 'planning' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  Planning
                </button>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap">
                <i className="ri-filter-line w-4 h-4 flex items-center justify-center"></i>
                <span className="text-sm">Filter</span>
              </button>
              <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap">
                <i className="ri-download-line w-4 h-4 flex items-center justify-center"></i>
                <span className="text-sm">Export</span>
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left py-4 px-6 font-medium text-gray-900">Project</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900">Status</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900">Progress</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900">Budget</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900">Timeline</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-900">Team</th>
                  <th className="text-right py-4 px-6 font-medium text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredProjects.map((project) => (
                  <tr key={project.id} className="hover:bg-gray-50">
                    <td className="py-4 px-6">
                      <div>
                        <h4 className="font-medium text-gray-900">{project.name}</h4>
                        <p className="text-sm text-gray-600">{project.location}</p>
                        <p className="text-xs text-gray-500 mt-1">Manager: {project.manager}</p>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusColors[project.status]}`}>
                        {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${project.progress}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium text-gray-900 w-10">{project.progress}%</span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-medium text-gray-900">{project.budget}</span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-sm">
                        <p className="text-gray-900">{project.startDate}</p>
                        <p className="text-gray-600">to {project.endDate}</p>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <i className="ri-team-line w-4 h-4 flex items-center justify-center text-gray-400"></i>
                        <span className="text-sm text-gray-900">{project.team}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center justify-end space-x-2">
                        <Link
                          href={`/projects/${project.id}`}
                          className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded"
                        >
                          <i className="ri-eye-line w-4 h-4 flex items-center justify-center"></i>
                        </Link>
                        <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                          <i className="ri-edit-line w-4 h-4 flex items-center justify-center"></i>
                        </button>
                        <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-red-600 hover:bg-red-50 rounded">
                          <i className="ri-delete-bin-line w-4 h-4 flex items-center justify-center"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}