
'use client';

import { useState } from 'react';
import Header from '@/components/Header';

interface Location {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  coordinates: string;
  projects: number;
  status: 'active' | 'inactive' | 'under-construction' | 'completed';
  manager: string;
  contact: string;
}

const locations: Location[] = [
  {
    id: '1',
    name: 'Downtown District Site',
    address: '1250 Biscayne Boulevard',
    city: 'Miami',
    state: 'FL',
    zipCode: '33132',
    coordinates: '25.7617, -80.1918',
    projects: 3,
    status: 'active',
    manager: 'John Smith',
    contact: '+1 (305) 555-0123',
  },
  {
    id: '2',
    name: 'Westside Development Zone',
    address: '4850 West Thomas Road',
    city: 'Phoenix',
    state: 'AZ',
    zipCode: '85031',
    coordinates: '33.4814, -112.1738',
    projects: 2,
    status: 'active',
    manager: 'Sarah Johnson',
    contact: '+1 (602) 555-0156',
  },
  {
    id: '3',
    name: 'Commercial Hub Area',
    address: '2100 Ross Avenue',
    city: 'Dallas',
    state: 'TX',
    zipCode: '75201',
    coordinates: '32.7881, -96.7902',
    projects: 1,
    status: 'active',
    manager: 'Mike Davis',
    contact: '+1 (214) 555-0189',
  },
  {
    id: '4',
    name: 'Suburban Residential Complex',
    address: '8900 Research Boulevard',
    city: 'Austin',
    state: 'TX',
    zipCode: '78758',
    coordinates: '30.3606, -97.7306',
    projects: 4,
    status: 'completed',
    manager: 'Lisa Chen',
    contact: '+1 (512) 555-0167',
  },
  {
    id: '5',
    name: 'Innovation District Campus',
    address: '400 Dexter Avenue North',
    city: 'Seattle',
    state: 'WA',
    zipCode: '98109',
    coordinates: '47.6235, -122.3493',
    projects: 1,
    status: 'under-construction',
    manager: 'Robert Wilson',
    contact: '+1 (206) 555-0134',
  },
];

const statusColors = {
  active: 'bg-green-100 text-green-800',
  inactive: 'bg-red-100 text-red-800',
  'under-construction': 'bg-yellow-100 text-yellow-800',
  completed: 'bg-blue-100 text-blue-800',
};

export default function ProjectLocationsPage() {
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    locationName: '',
    city: '',
    status: 'active' as 'active' | 'inactive' | 'under-construction' | 'completed',
  });

  const filteredLocations = locations.filter((location) =>
    location.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    location.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
    location.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddLocation = () => {
    setShowAddModal(true);
  };

  const handleCloseModal = () => {
    setShowAddModal(false);
    setFormData({
      locationName: '',
      city: '',
      status: 'active',
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('New location data:', formData);
    handleCloseModal();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Project Locations</h1>
            <p className="text-gray-600">Manage all construction site locations and coordinates</p>
          </div>

          <button
            onClick={handleAddLocation}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap"
          >
            <i className="ri-map-pin-add-line w-4 h-4 flex items-center justify-center"></i>
            <span>Add Location</span>
          </button>
        </div>

        {showAddModal && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">Add New Location</h3>
                  <button
                    onClick={handleCloseModal}
                    className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded"
                  >
                    <i className="ri-close-line w-5 h-5 flex items-center justify-center"></i>
                  </button>
                </div>
              </div>

              <form id="add-location-form" onSubmit={handleSubmit} className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label htmlFor="locationName" className="block text-sm font-medium text-gray-700 mb-1">
                      Location Name *
                    </label>
                    <input
                      type="text"
                      id="locationName"
                      name="locationName"
                      value={formData.locationName}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter location name"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                      City *
                    </label>
                    <input
                      type="text"
                      id="city"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter city"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
                      Status *
                    </label>
                    <select
                      id="status"
                      name="status"
                      value={formData.status}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-8"
                      required
                    >
                      <option value="">Select status</option>
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                      <option value="under-construction">Under Construction</option>
                      <option value="completed">Completed</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center justify-end space-x-4 mt-8 pt-6 border-t border-gray-200">
                  <button
                    type="button"
                    onClick={handleCloseModal}
                    className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 whitespace-nowrap"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center justify-center space-x-2 whitespace-nowrap"
                  >
                    <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
                    <span>Add Location</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">All Locations</h3>
                <div className="relative">
                  <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center text-gray-400"></i>
                  <input
                    type="text"
                    placeholder="Search locations..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  />
                </div>
              </div>

              <div className="space-y-4">
                {filteredLocations.map((location) => (
                  <div
                    key={location.id}
                    onClick={() => setSelectedLocation(location)}
                    className={`p-4 border rounded-lg cursor-pointer transition-all ${
                      selectedLocation?.id === location.id
                        ? 'border-blue-300 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h4 className="font-medium text-gray-900">{location.name}</h4>
                          <span
                            className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusColors[location.status]}`}
                          >
                            {location.status.charAt(0).toUpperCase() + location.status.slice(1)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{location.address}</p>
                        <p className="text-sm text-gray-600 mb-2">{location.city}, {location.state} {location.zipCode}</p>
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <div className="flex items-center space-x-1">
                            <i className="ri-building-line w-3 h-3 flex items-center justify-center"></i>
                            <span>{location.projects} projects</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <i className="ri-user-line w-3 h-3 flex items-center justify-center"></i>
                            <span>{location.manager}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-100 rounded">
                          <i className="ri-edit-line w-4 h-4 flex items-center justify-center"></i>
                        </button>
                        <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-red-600 hover:bg-red-100 rounded">
                          <i className="ri-delete-bin-line w-4 h-4 flex items-center justify-center"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {selectedLocation && (
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Location Details</h3>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Location Name</label>
                    <p className="text-sm text-gray-900 mt-1">{selectedLocation.name}</p>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700">Full Address</label>
                    <p className="text-sm text-gray-900 mt-1">
                      {selectedLocation.address}
                      <br />
                      {selectedLocation.city}, {selectedLocation.state} {selectedLocation.zipCode}
                    </p>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700">Coordinates</label>
                    <p className="text-sm text-gray-900 mt-1">{selectedLocation.coordinates}</p>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700">Site Manager</label>
                    <p className="text-sm text-gray-900 mt-1">{selectedLocation.manager}</p>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700">Contact Number</label>
                    <p className="text-sm text-gray-900 mt-1">{selectedLocation.contact}</p>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700">Active Projects</label>
                    <p className="text-sm text-gray-900 mt-1">{selectedLocation.projects} projects</p>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700">Status</label>
                    <span
                      className={`inline-flex px-2 py-1 text-xs font-medium rounded-full mt-1 ${statusColors[selectedLocation.status]}`}
                    >
                      {selectedLocation.status.charAt(0).toUpperCase() + selectedLocation.status.slice(1)}
                    </span>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-gray-200">
                  <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 flex items-center justify-center space-x-2 whitespace-nowrap">
                    <i className="ri-map-line w-4 h-4 flex items-center justify-center"></i>
                    <span>View on Map</span>
                  </button>
                </div>
              </div>
            )}

            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Map View</h3>
              <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8354345093634!2d144.9537353153167!3d-37.81627997975195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65d43f3f8c387%3A0x2fe2b0b2b4a3b3!2sConstruction%20Site!5e0!3m2!1sen!2sus!4v1644444444444!5m2!1sen!2sus"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="rounded-lg"
                ></iframe>
              </div>
              <p className="text-xs text-gray-500 mt-2">Interactive map showing all project locations</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
