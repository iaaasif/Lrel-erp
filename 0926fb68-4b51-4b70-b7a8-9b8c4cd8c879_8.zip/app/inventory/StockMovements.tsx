'use client';

import { useState } from 'react';

interface StockMovement {
  id: string;
  date: string;
  time: string;
  type: 'IN' | 'OUT' | 'TRANSFER' | 'ADJUSTMENT';
  material: string;
  materialCode: string;
  quantity: number;
  unit: string;
  fromLocation?: string;
  toLocation: string;
  project?: string;
  reference: string;
  handledBy: string;
  reason?: string;
  status: 'Completed' | 'Pending' | 'Cancelled';
}

const movements: StockMovement[] = [
  {
    id: '1',
    date: '2024-01-15',
    time: '09:30',
    type: 'IN',
    material: 'Steel Beams I-Section',
    materialCode: 'STL-002',
    quantity: 150,
    unit: 'pieces',
    toLocation: 'Main Warehouse',
    reference: 'PO-2024-001',
    handledBy: 'John Mitchell',
    status: 'Completed'
  },
  {
    id: '2',
    date: '2024-01-15',
    time: '14:15',
    type: 'OUT',
    material: 'Cement Portland Grade 53',
    materialCode: 'CEM-001',
    quantity: 80,
    unit: 'bags',
    fromLocation: 'Main Warehouse',
    toLocation: 'Ocean View Project Site',
    project: 'Ocean View Towers',
    reference: 'REQ-2024-015',
    handledBy: 'Sarah Johnson',
    status: 'Completed'
  },
  {
    id: '3',
    date: '2024-01-14',
    time: '11:20',
    type: 'TRANSFER',
    material: 'Aggregate Stone 20mm',
    materialCode: 'AGG-001',
    quantity: 25,
    unit: 'tons',
    fromLocation: 'Main Warehouse',
    toLocation: 'Site Storage A',
    project: 'Sunset Residences',
    reference: 'TRF-2024-008',
    handledBy: 'Mike Davis',
    status: 'Completed'
  },
  {
    id: '4',
    date: '2024-01-14',
    time: '16:45',
    type: 'OUT',
    material: 'Clay Bricks Standard',
    materialCode: 'BRK-001',
    quantity: 2500,
    unit: 'pieces',
    fromLocation: 'Site Storage B',
    toLocation: 'City Mall Project Site',
    project: 'City Mall Extension',
    reference: 'REQ-2024-016',
    handledBy: 'Robert Wilson',
    status: 'Completed'
  },
  {
    id: '5',
    date: '2024-01-13',
    time: '10:00',
    type: 'IN',
    material: 'PVC Pipes 4 inch',
    materialCode: 'PVC-001',
    quantity: 200,
    unit: 'meters',
    toLocation: 'Equipment Storage',
    reference: 'PO-2024-002',
    handledBy: 'Lisa Chen',
    status: 'Completed'
  },
  {
    id: '6',
    date: '2024-01-13',
    time: '13:30',
    type: 'ADJUSTMENT',
    material: 'Electrical Wire 2.5mm',
    materialCode: 'ELE-001',
    quantity: -15,
    unit: 'meters',
    toLocation: 'Equipment Storage',
    reference: 'ADJ-2024-003',
    handledBy: 'Lisa Chen',
    reason: 'Damaged during transport',
    status: 'Completed'
  },
  {
    id: '7',
    date: '2024-01-12',
    time: '08:45',
    type: 'OUT',
    material: 'Safety Helmets',
    materialCode: 'SAF-001',
    quantity: 15,
    unit: 'pieces',
    fromLocation: 'Equipment Storage',
    toLocation: 'Ocean View Project Site',
    project: 'Ocean View Towers',
    reference: 'REQ-2024-017',
    handledBy: 'Sarah Johnson',
    status: 'Pending'
  },
  {
    id: '8',
    date: '2024-01-12',
    time: '15:20',
    type: 'IN',
    material: 'Exterior Paint White',
    materialCode: 'PAI-001',
    quantity: 50,
    unit: 'liters',
    toLocation: 'Main Warehouse',
    reference: 'PO-2024-003',
    handledBy: 'John Mitchell',
    status: 'Completed'
  }
];

const typeColors = {
  'IN': 'bg-green-100 text-green-800',
  'OUT': 'bg-red-100 text-red-800',
  'TRANSFER': 'bg-blue-100 text-blue-800',
  'ADJUSTMENT': 'bg-yellow-100 text-yellow-800'
};

const statusColors = {
  'Completed': 'bg-green-100 text-green-800',
  'Pending': 'bg-yellow-100 text-yellow-800',
  'Cancelled': 'bg-red-100 text-red-800'
};

export default function StockMovements() {
  const [selectedType, setSelectedType] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState('7');

  const movementTypes = ['All', 'IN', 'OUT', 'TRANSFER', 'ADJUSTMENT'];
  const statusOptions = ['All', 'Completed', 'Pending', 'Cancelled'];

  const filteredMovements = movements.filter(movement => {
    const matchesType = selectedType === 'All' || movement.type === selectedType;
    const matchesStatus = selectedStatus === 'All' || movement.status === selectedStatus;
    const matchesSearch = movement.material.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         movement.materialCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         movement.reference.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center text-gray-400"></i>
            <input
              type="text"
              placeholder="Search movements..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            {movementTypes.map(type => (
              <option key={type} value={type}>{type === 'All' ? 'All Types' : type}</option>
            ))}
          </select>
          
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            {statusOptions.map(status => (
              <option key={status} value={status}>{status === 'All' ? 'All Status' : status}</option>
            ))}
          </select>
          
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
          </select>
        </div>
        
        <div className="flex items-center space-x-3">
          <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap">
            <i className="ri-download-line w-4 h-4 flex items-center justify-center"></i>
            <span className="text-sm">Export</span>
          </button>
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
            <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
            <span>New Movement</span>
          </button>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white border-b border-gray-200">
              <tr>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Date & Time</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Type</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Material</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Quantity</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Location</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Reference</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Handled By</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Status</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {filteredMovements.map((movement) => (
                <tr key={movement.id} className="hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <div>
                      <span className="text-sm font-medium text-gray-900">{movement.date}</span>
                      <p className="text-xs text-gray-600">{movement.time}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${typeColors[movement.type]}`}>
                      {movement.type}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <span className="text-sm font-medium text-gray-900">{movement.material}</span>
                      <p className="text-xs text-gray-600">{movement.materialCode}</p>
                      {movement.project && (
                        <p className="text-xs text-blue-600">{movement.project}</p>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <span className={`text-sm font-medium ${movement.quantity < 0 ? 'text-red-600' : 'text-gray-900'}`}>
                      {movement.quantity > 0 ? '+' : ''}{movement.quantity} {movement.unit}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="text-sm">
                      {movement.fromLocation && (
                        <p className="text-gray-600">From: {movement.fromLocation}</p>
                      )}
                      <p className="text-gray-900">
                        {movement.type === 'IN' ? 'To: ' : movement.type === 'OUT' ? 'To: ' : 'To: '}
                        {movement.toLocation}
                      </p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-mono text-gray-900">{movement.reference}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{movement.handledBy}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusColors[movement.status]}`}>
                      {movement.status}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center justify-end space-x-2">
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <i className="ri-eye-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-green-600 hover:bg-green-50 rounded">
                        <i className="ri-printer-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Today's Movements</p>
              <p className="text-2xl font-bold text-gray-900">
                {movements.filter(m => m.date === '2024-01-15').length}
              </p>
            </div>
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <i className="ri-truck-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending Movements</p>
              <p className="text-2xl font-bold text-gray-900">
                {movements.filter(m => m.status === 'Pending').length}
              </p>
            </div>
            <div className="w-10 h-10 bg-yellow-600 rounded-lg flex items-center justify-center">
              <i className="ri-time-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Materials In</p>
              <p className="text-2xl font-bold text-gray-900">
                {movements.filter(m => m.type === 'IN').length}
              </p>
            </div>
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
              <i className="ri-arrow-down-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Materials Out</p>
              <p className="text-2xl font-bold text-gray-900">
                {movements.filter(m => m.type === 'OUT').length}
              </p>
            </div>
            <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center">
              <i className="ri-arrow-up-line text-white w-5 h-5 flex items-center justify-center"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}