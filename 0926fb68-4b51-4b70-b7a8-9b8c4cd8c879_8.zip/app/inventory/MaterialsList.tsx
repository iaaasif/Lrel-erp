'use client';

import { useState } from 'react';

interface Material {
  id: string;
  code: string;
  name: string;
  category: string;
  unit: string;
  currentStock: number;
  minimumStock: number;
  averageCost: number;
  totalValue: number;
  lastRestocked: string;
  supplier: string;
  location: string;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
}

const materials: Material[] = [
  {
    id: '1',
    code: 'STL-001',
    name: 'Steel Rebar 12mm',
    category: 'Steel',
    unit: 'tons',
    currentStock: 45,
    minimumStock: 100,
    averageCost: 850,
    totalValue: 38250,
    lastRestocked: '2024-01-10',
    supplier: 'Metro Steel Co.',
    location: 'Main Warehouse',
    status: 'Low Stock'
  },
  {
    id: '2',
    code: 'CEM-001',
    name: 'Cement Portland Grade 53',
    category: 'Cement',
    unit: 'bags',
    currentStock: 450,
    minimumStock: 200,
    averageCost: 12,
    totalValue: 5400,
    lastRestocked: '2024-01-14',
    supplier: 'BuildCorp Supplies',
    location: 'Main Warehouse',
    status: 'In Stock'
  },
  {
    id: '3',
    code: 'AGG-001',
    name: 'Aggregate Stone 20mm',
    category: 'Aggregates',
    unit: 'tons',
    currentStock: 120,
    minimumStock: 80,
    averageCost: 45,
    totalValue: 5400,
    lastRestocked: '2024-01-13',
    supplier: 'Stone Quarry Ltd.',
    location: 'Site Storage A',
    status: 'In Stock'
  },
  {
    id: '4',
    code: 'BRK-001',
    name: 'Clay Bricks Standard',
    category: 'Bricks',
    unit: 'pieces',
    currentStock: 8500,
    minimumStock: 5000,
    averageCost: 0.8,
    totalValue: 6800,
    lastRestocked: '2024-01-12',
    supplier: 'Brick Manufacturing Co.',
    location: 'Site Storage B',
    status: 'In Stock'
  },
  {
    id: '5',
    code: 'PVC-001',
    name: 'PVC Pipes 4 inch',
    category: 'Plumbing',
    unit: 'meters',
    currentStock: 180,
    minimumStock: 200,
    averageCost: 15,
    totalValue: 2700,
    lastRestocked: '2024-01-08',
    supplier: 'Pipe Solutions Inc.',
    location: 'Equipment Storage',
    status: 'Low Stock'
  },
  {
    id: '6',
    code: 'ELE-001',
    name: 'Electrical Wire 2.5mm',
    category: 'Electrical',
    unit: 'meters',
    currentStock: 85,
    minimumStock: 150,
    averageCost: 3.5,
    totalValue: 297.5,
    lastRestocked: '2024-01-05',
    supplier: 'ElectroMax Ltd.',
    location: 'Equipment Storage',
    status: 'Low Stock'
  },
  {
    id: '7',
    code: 'SAF-001',
    name: 'Safety Helmets',
    category: 'Safety',
    unit: 'pieces',
    currentStock: 0,
    minimumStock: 30,
    averageCost: 25,
    totalValue: 0,
    lastRestocked: '2023-12-28',
    supplier: 'Safety First Co.',
    location: 'Equipment Storage',
    status: 'Out of Stock'
  },
  {
    id: '8',
    code: 'PAI-001',
    name: 'Exterior Paint White',
    category: 'Paint',
    unit: 'liters',
    currentStock: 125,
    minimumStock: 50,
    averageCost: 18,
    totalValue: 2250,
    lastRestocked: '2024-01-11',
    supplier: 'ColorPro Paints',
    location: 'Main Warehouse',
    status: 'In Stock'
  }
];

const categories = ['All', 'Steel', 'Cement', 'Aggregates', 'Bricks', 'Plumbing', 'Electrical', 'Safety', 'Paint'];
const statusColors = {
  'In Stock': 'bg-green-100 text-green-800',
  'Low Stock': 'bg-yellow-100 text-yellow-800',
  'Out of Stock': 'bg-red-100 text-red-800'
};

export default function MaterialsList() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('name');

  const filteredMaterials = materials.filter(material => {
    const matchesCategory = selectedCategory === 'All' || material.category === selectedCategory;
    const matchesSearch = material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.supplier.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center text-gray-400"></i>
            <input
              type="text"
              placeholder="Search materials..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                  selectedCategory === category 
                    ? 'bg-blue-100 text-blue-800' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm pr-8"
          >
            <option value="name">Sort by Name</option>
            <option value="stock">Sort by Stock</option>
            <option value="value">Sort by Value</option>
            <option value="status">Sort by Status</option>
          </select>
          
          <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap">
            <i className="ri-download-line w-4 h-4 flex items-center justify-center"></i>
            <span className="text-sm">Export</span>
          </button>
          
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
            <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
            <span>Add Material</span>
          </button>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white border-b border-gray-200">
              <tr>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Material Code</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Material Name</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Category</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Current Stock</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Min Stock</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Unit Cost</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Total Value</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Status</th>
                <th className="text-left py-4 px-6 font-medium text-gray-900">Location</th>
                <th className="text-right py-4 px-6 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {filteredMaterials.map((material) => (
                <tr key={material.id} className="hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <span className="font-mono text-sm font-medium text-gray-900">{material.code}</span>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <span className="font-medium text-gray-900">{material.name}</span>
                      <p className="text-sm text-gray-600">{material.supplier}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{material.category}</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <span className="font-medium text-gray-900">
                      {material.currentStock} {material.unit}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <span className="text-sm text-gray-600">
                      {material.minimumStock} {material.unit}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <span className="text-sm text-gray-900">${material.averageCost}</span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <span className="font-medium text-gray-900">${material.totalValue.toLocaleString()}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusColors[material.status]}`}>
                      {material.status}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{material.location}</span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center justify-end space-x-2">
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <i className="ri-eye-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                        <i className="ri-edit-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                      <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-green-600 hover:bg-green-50 rounded">
                        <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex items-center justify-between text-sm text-gray-600">
        <div>
          Showing {filteredMaterials.length} of {materials.length} materials
        </div>
        <div className="flex items-center space-x-2">
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 whitespace-nowrap">
            Previous
          </button>
          <span className="px-3 py-1">1 of 2</span>
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 whitespace-nowrap">
            Next
          </button>
        </div>
      </div>
    </div>
  );
}