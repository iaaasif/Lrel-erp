'use client';

import { useState } from 'react';

interface Warehouse {
  id: string;
  name: string;
  type: 'Main Warehouse' | 'Site Storage' | 'Equipment Storage';
  location: string;
  manager: string;
  contact: string;
  totalCapacity: number;
  usedCapacity: number;
  availableCapacity: number;
  utilizationRate: number;
  status: 'Active' | 'Maintenance' | 'Inactive';
  materialTypes: string[];
  lastInspection: string;
}

const warehouses: Warehouse[] = [
  {
    id: '1',
    name: 'Main Warehouse',
    type: 'Main Warehouse',
    location: '123 Industrial Avenue, Metro City',
    manager: 'John Mitchell',
    contact: '+1 (555) 123-4567',
    totalCapacity: 1000,
    usedCapacity: 750,
    availableCapacity: 250,
    utilizationRate: 75,
    status: 'Active',
    materialTypes: ['Steel', 'Cement', 'Paint', 'Tools'],
    lastInspection: '2024-01-10'
  },
  {
    id: '2',
    name: 'Site Storage A',
    type: 'Site Storage',
    location: 'Ocean View Project Site',
    manager: 'Sarah Johnson',
    contact: '+1 (555) 234-5678',
    totalCapacity: 500,
    usedCapacity: 420,
    availableCapacity: 80,
    utilizationRate: 84,
    status: 'Active',
    materialTypes: ['Aggregates', 'Bricks', 'Cement'],
    lastInspection: '2024-01-12'
  },
  {
    id: '3',
    name: 'Site Storage B',
    type: 'Site Storage',
    location: 'Sunset Residences Project Site',
    manager: 'Mike Davis',
    contact: '+1 (555) 345-6789',
    totalCapacity: 300,
    usedCapacity: 180,
    availableCapacity: 120,
    utilizationRate: 60,
    status: 'Active',
    materialTypes: ['Bricks', 'Roofing', 'Tiles'],
    lastInspection: '2024-01-08'
  },
  {
    id: '4',
    name: 'Equipment Storage',
    type: 'Equipment Storage',
    location: '456 Equipment Park, Metro City',
    manager: 'Lisa Chen',
    contact: '+1 (555) 456-7890',
    totalCapacity: 800,
    usedCapacity: 640,
    availableCapacity: 160,
    utilizationRate: 80,
    status: 'Active',
    materialTypes: ['Electrical', 'Plumbing', 'Safety', 'Tools'],
    lastInspection: '2024-01-14'
  },
  {
    id: '5',
    name: 'Temporary Storage C',
    type: 'Site Storage',
    location: 'City Mall Extension Site',
    manager: 'Robert Wilson',
    contact: '+1 (555) 567-8901',
    totalCapacity: 200,
    usedCapacity: 45,
    availableCapacity: 155,
    utilizationRate: 23,
    status: 'Maintenance',
    materialTypes: ['Steel', 'Concrete'],
    lastInspection: '2024-01-05'
  }
];

const statusColors = {
  'Active': 'bg-green-100 text-green-800',
  'Maintenance': 'bg-yellow-100 text-yellow-800',
  'Inactive': 'bg-red-100 text-red-800'
};

export default function WarehouseManagement() {
  const [selectedType, setSelectedType] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const warehouseTypes = ['All', 'Main Warehouse', 'Site Storage', 'Equipment Storage'];

  const filteredWarehouses = warehouses.filter(warehouse => {
    const matchesType = selectedType === 'All' || warehouse.type === selectedType;
    const matchesSearch = warehouse.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         warehouse.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         warehouse.manager.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center text-gray-400"></i>
            <input
              type="text"
              placeholder="Search warehouses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            {warehouseTypes.map((type) => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
                  selectedType === type 
                    ? 'bg-blue-100 text-blue-800' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>
        
        <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
          <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
          <span>Add Warehouse</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredWarehouses.map((warehouse) => (
          <div key={warehouse.id} className="bg-gray-50 rounded-lg p-6 border border-gray-200">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{warehouse.name}</h3>
                <p className="text-sm text-gray-600">{warehouse.type}</p>
              </div>
              <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusColors[warehouse.status]}`}>
                {warehouse.status}
              </span>
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <i className="ri-map-pin-line w-4 h-4 flex items-center justify-center mr-2"></i>
                <span>{warehouse.location}</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <i className="ri-user-line w-4 h-4 flex items-center justify-center mr-2"></i>
                <span>{warehouse.manager}</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <i className="ri-phone-line w-4 h-4 flex items-center justify-center mr-2"></i>
                <span>{warehouse.contact}</span>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Capacity Utilization</span>
                <span className="text-sm font-medium text-gray-900">{warehouse.utilizationRate}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full ${
                    warehouse.utilizationRate >= 90 ? 'bg-red-500' :
                    warehouse.utilizationRate >= 75 ? 'bg-yellow-500' : 'bg-green-500'
                  }`}
                  style={{ width: `${warehouse.utilizationRate}%` }}
                ></div>
              </div>
              <div className="flex items-center justify-between mt-2 text-xs text-gray-600">
                <span>Used: {warehouse.usedCapacity} units</span>
                <span>Available: {warehouse.availableCapacity} units</span>
              </div>
            </div>

            <div className="mb-4">
              <p className="text-sm font-medium text-gray-700 mb-2">Material Types</p>
              <div className="flex flex-wrap gap-1">
                {warehouse.materialTypes.map((type, index) => (
                  <span key={index} className="inline-flex px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full">
                    {type}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-gray-600 mb-4">
              <span>Last Inspection: {warehouse.lastInspection}</span>
            </div>

            <div className="flex items-center space-x-2">
              <button className="flex-1 bg-white border border-gray-300 text-gray-700 px-3 py-2 rounded-lg hover:bg-gray-50 text-sm whitespace-nowrap">
                View Details
              </button>
              <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded">
                <i className="ri-edit-line w-4 h-4 flex items-center justify-center"></i>
              </button>
              <button className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-green-600 hover:bg-green-50 rounded">
                <i className="ri-truck-line w-4 h-4 flex items-center justify-center"></i>
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Capacity Summary</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Total Capacity</span>
              <span className="font-medium text-gray-900">
                {warehouses.reduce((sum, w) => sum + w.totalCapacity, 0)} units
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Used Capacity</span>
              <span className="font-medium text-gray-900">
                {warehouses.reduce((sum, w) => sum + w.usedCapacity, 0)} units
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Available Capacity</span>
              <span className="font-medium text-green-600">
                {warehouses.reduce((sum, w) => sum + w.availableCapacity, 0)} units
              </span>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Status Overview</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-600">Active</span>
              </div>
              <span className="font-medium text-gray-900">
                {warehouses.filter(w => w.status === 'Active').length}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-600">Maintenance</span>
              </div>
              <span className="font-medium text-gray-900">
                {warehouses.filter(w => w.status === 'Maintenance').length}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                <span className="text-sm text-gray-600">Inactive</span>
              </div>
              <span className="font-medium text-gray-900">
                {warehouses.filter(w => w.status === 'Inactive').length}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-2">
            <button className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm whitespace-nowrap">
              Schedule Inspection
            </button>
            <button className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-sm whitespace-nowrap">
              Transfer Materials
            </button>
            <button className="w-full bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 text-sm whitespace-nowrap">
              Generate Report
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}