'use client';

export default function InventoryOverview() {
  const summaryCards = [
    {
      title: 'Total Materials',
      value: '2,450',
      change: '+12%',
      isPositive: true,
      icon: 'ri-building-line',
      color: 'bg-blue-600'
    },
    {
      title: 'Low Stock Items',
      value: '23',
      change: '-5%',
      isPositive: true,
      icon: 'ri-alert-line',
      color: 'bg-orange-600'
    },
    {
      title: 'Total Value',
      value: '$2.8M',
      change: '+8%',
      isPositive: true,
      icon: 'ri-money-dollar-circle-line',
      color: 'bg-green-600'
    },
    {
      title: 'Active Warehouses',
      value: '8',
      change: '0%',
      isPositive: true,
      icon: 'ri-store-line',
      color: 'bg-purple-600'
    }
  ];

  const lowStockItems = [
    { name: 'Steel Rebar 12mm', current: 45, minimum: 100, unit: 'tons', priority: 'High' },
    { name: 'Concrete Mix Grade 30', current: 25, minimum: 50, unit: 'bags', priority: 'High' },
    { name: 'PVC Pipes 4 inch', current: 180, minimum: 200, unit: 'meters', priority: 'Medium' },
    { name: 'Safety Helmets', current: 15, minimum: 30, unit: 'pieces', priority: 'Medium' },
    { name: 'Electrical Wire 2.5mm', current: 85, minimum: 150, unit: 'meters', priority: 'Low' }
  ];

  const recentMovements = [
    {
      type: 'IN',
      material: 'Steel Beams I-Section',
      quantity: 150,
      unit: 'pieces',
      warehouse: 'Main Warehouse',
      date: '2024-01-15',
      project: 'Ocean View Towers'
    },
    {
      type: 'OUT',
      material: 'Cement Portland',
      quantity: 80,
      unit: 'bags',
      warehouse: 'Site Storage A',
      date: '2024-01-14',
      project: 'Sunset Residences'
    },
    {
      type: 'IN',
      material: 'Aggregate Stone',
      quantity: 45,
      unit: 'tons',
      warehouse: 'Main Warehouse',
      date: '2024-01-13',
      project: 'City Mall Extension'
    },
    {
      type: 'OUT',
      material: 'Roofing Sheets',
      quantity: 220,
      unit: 'sheets',
      warehouse: 'Site Storage B',
      date: '2024-01-12',
      project: 'Industrial Complex'
    }
  ];

  const warehouseUtilization = [
    { name: 'Main Warehouse', capacity: 1000, used: 750, percentage: 75 },
    { name: 'Site Storage A', capacity: 500, used: 420, percentage: 84 },
    { name: 'Site Storage B', capacity: 300, used: 180, percentage: 60 },
    { name: 'Equipment Storage', capacity: 800, used: 640, percentage: 80 }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {summaryCards.map((card, index) => (
          <div key={index} className="bg-gray-50 rounded-lg p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-gray-600 text-sm font-medium">{card.title}</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">{card.value}</p>
                <div className="flex items-center mt-2">
                  <i className={`${card.isPositive ? 'ri-arrow-up-line text-green-600' : 'ri-arrow-down-line text-red-600'} w-4 h-4 flex items-center justify-center mr-1`}></i>
                  <span className={`text-sm font-medium ${card.isPositive ? 'text-green-600' : 'text-red-600'}`}>
                    {card.change}
                  </span>
                  <span className="text-gray-500 text-sm ml-1">vs last month</span>
                </div>
              </div>
              <div className={`w-12 h-12 ${card.color} rounded-lg flex items-center justify-center`}>
                <i className={`${card.icon} text-white w-6 h-6 flex items-center justify-center`}></i>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-50 rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Low Stock Alert</h3>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium whitespace-nowrap">
              View All
            </button>
          </div>
          <div className="space-y-4">
            {lowStockItems.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{item.name}</h4>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                      item.priority === 'High' ? 'bg-red-100 text-red-800' :
                      item.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {item.priority}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span>Current: {item.current} {item.unit}</span>
                    <span>Minimum: {item.minimum} {item.unit}</span>
                  </div>
                  <div className="mt-2">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          (item.current / item.minimum) < 0.5 ? 'bg-red-500' :
                          (item.current / item.minimum) < 0.8 ? 'bg-yellow-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${Math.min((item.current / item.minimum) * 100, 100)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Recent Stock Movements</h3>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium whitespace-nowrap">
              View All
            </button>
          </div>
          <div className="space-y-3">
            {recentMovements.map((movement, index) => (
              <div key={index} className="flex items-center space-x-4 p-3 bg-white rounded-lg">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  movement.type === 'IN' ? 'bg-green-100' : 'bg-red-100'
                }`}>
                  <i className={`${
                    movement.type === 'IN' ? 'ri-arrow-down-line text-green-600' : 'ri-arrow-up-line text-red-600'
                  } w-4 h-4 flex items-center justify-center`}></i>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{movement.material}</p>
                  <p className="text-xs text-gray-600">
                    {movement.quantity} {movement.unit} • {movement.warehouse}
                  </p>
                  <p className="text-xs text-gray-500">{movement.project} • {movement.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Warehouse Utilization</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {warehouseUtilization.map((warehouse, index) => (
            <div key={index} className="bg-white rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-gray-900">{warehouse.name}</h4>
                <span className="text-sm font-medium text-gray-600">{warehouse.percentage}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
                <div 
                  className={`h-3 rounded-full ${
                    warehouse.percentage >= 90 ? 'bg-red-500' :
                    warehouse.percentage >= 75 ? 'bg-yellow-500' : 'bg-green-500'
                  }`}
                  style={{ width: `${warehouse.percentage}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-600">
                {warehouse.used} / {warehouse.capacity} units
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}