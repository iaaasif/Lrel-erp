'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import InventoryOverview from './InventoryOverview';
import MaterialsList from './MaterialsList';
import WarehouseManagement from './WarehouseManagement';
import StockMovements from './StockMovements';

export default function InventoryPage() {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'ri-dashboard-line' },
    { id: 'materials', label: 'Materials', icon: 'ri-building-line' },
    { id: 'warehouse', label: 'Warehouse', icon: 'ri-store-line' },
    { id: 'movements', label: 'Stock Movements', icon: 'ri-truck-line' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Inventory Management</h1>
            <p className="text-gray-600">Track materials, supplies and warehouse operations</p>
          </div>
          
          <div className="flex items-center space-x-3">
            <button className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2 whitespace-nowrap">
              <i className="ri-add-line w-4 h-4 flex items-center justify-center"></i>
              <span>Add Material</span>
            </button>
            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 whitespace-nowrap">
              <i className="ri-truck-line w-4 h-4 flex items-center justify-center"></i>
              <span>Stock Transfer</span>
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 border-b-2 font-medium text-sm transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <i className={`${tab.icon} w-4 h-4 flex items-center justify-center`}></i>
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>
          
          <div className="p-6">
            {activeTab === 'overview' && <InventoryOverview />}
            {activeTab === 'materials' && <MaterialsList />}
            {activeTab === 'warehouse' && <WarehouseManagement />}
            {activeTab === 'movements' && <StockMovements />}
          </div>
        </div>
      </main>
    </div>
  );
}