'use client';

import Header from '@/components/Header';
import DashboardCard from '@/components/DashboardCard';
import RecentActivity from '@/components/RecentActivity';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="p-6">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Construction ERP Dashboard</h1>
          <p className="text-gray-600">Welcome back! Here's what's happening with your construction projects.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <DashboardCard
            title="Active Projects"
            value="24"
            subtitle="8 nearing completion"
            icon="ri-building-line"
            color="bg-blue-600"
            trend={{ value: "12%", isUp: true }}
          />
          <DashboardCard
            title="Total Revenue"
            value="$2.4M"
            subtitle="This quarter"
            icon="ri-money-dollar-circle-line"
            color="bg-green-600"
            trend={{ value: "8%", isUp: true }}
          />
          <DashboardCard
            title="Pending Orders"
            value="156"
            subtitle="Purchase orders"
            icon="ri-shopping-cart-line"
            color="bg-orange-600"
            trend={{ value: "3%", isUp: false }}
          />
          <DashboardCard
            title="Team Members"
            value="342"
            subtitle="Active employees"
            icon="ri-team-line"
            color="bg-purple-600"
            trend={{ value: "5%", isUp: true }}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">Project Progress Overview</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                      <i className="ri-building-line text-white w-5 h-5 flex items-center justify-center"></i>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Ocean View Towers</h4>
                      <p className="text-xs text-gray-600">Downtown District</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">85%</div>
                    <div className="w-20 bg-gray-200 rounded-full h-2 mt-1">
                      <div className="bg-blue-600 h-2 rounded-full" style={{width: '85%'}}></div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                      <i className="ri-home-line text-white w-5 h-5 flex items-center justify-center"></i>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Sunset Residences</h4>
                      <p className="text-xs text-gray-600">Westside Area</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">92%</div>
                    <div className="w-20 bg-gray-200 rounded-full h-2 mt-1">
                      <div className="bg-green-600 h-2 rounded-full" style={{width: '92%'}}></div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center">
                      <i className="ri-store-line text-white w-5 h-5 flex items-center justify-center"></i>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">City Mall Extension</h4>
                      <p className="text-xs text-gray-600">Commercial Hub</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">67%</div>
                    <div className="w-20 bg-gray-200 rounded-full h-2 mt-1">
                      <div className="bg-orange-600 h-2 rounded-full" style={{width: '67%'}}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <RecentActivity />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-4">
              <button className="flex flex-col items-center p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all whitespace-nowrap">
                <i className="ri-add-line w-6 h-6 flex items-center justify-center text-blue-600 mb-2"></i>
                <span className="text-sm font-medium text-gray-700">New Project</span>
              </button>
              <button className="flex flex-col items-center p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:bg-green-50 transition-all whitespace-nowrap">
                <i className="ri-shopping-cart-line w-6 h-6 flex items-center justify-center text-green-600 mb-2"></i>
                <span className="text-sm font-medium text-gray-700">Purchase Order</span>
              </button>
              <button className="flex flex-col items-center p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-all whitespace-nowrap">
                <i className="ri-user-add-line w-6 h-6 flex items-center justify-center text-purple-600 mb-2"></i>
                <span className="text-sm font-medium text-gray-700">Add Employee</span>
              </button>
              <button className="flex flex-col items-center p-4 border border-gray-200 rounded-lg hover:border-orange-300 hover:bg-orange-50 transition-all whitespace-nowrap">
                <i className="ri-file-text-line w-6 h-6 flex items-center justify-center text-orange-600 mb-2"></i>
                <span className="text-sm font-medium text-gray-700">Generate Report</span>
              </button>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Inventory Alerts</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <i className="ri-alert-line w-5 h-5 flex items-center justify-center text-red-600"></i>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Cement</p>
                    <p className="text-xs text-gray-600">50 bags remaining</p>
                  </div>
                </div>
                <span className="text-xs font-medium text-red-600 bg-red-100 px-2 py-1 rounded">Critical</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <i className="ri-alert-line w-5 h-5 flex items-center justify-center text-yellow-600"></i>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Steel Rods</p>
                    <p className="text-xs text-gray-600">200 units remaining</p>
                  </div>
                </div>
                <span className="text-xs font-medium text-yellow-600 bg-yellow-100 px-2 py-1 rounded">Low</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <i className="ri-alert-line w-5 h-5 flex items-center justify-center text-yellow-600"></i>
                  <div>
                    <p className="text-sm font-medium text-gray-900">Paint</p>
                    <p className="text-xs text-gray-600">75 gallons remaining</p>
                  </div>
                </div>
                <span className="text-xs font-medium text-yellow-600 bg-yellow-100 px-2 py-1 rounded">Low</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}